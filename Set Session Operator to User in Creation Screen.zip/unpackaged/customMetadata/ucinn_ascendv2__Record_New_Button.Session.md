<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Session</label>
    <protected>false</protected>
    <values>
        <field>ucinn_ascendv2__Base_Object__c</field>
        <value xsi:type="xsd:string">ucinn_ascendv2__Session__c</value>
    </values>
</CustomMetadata>
